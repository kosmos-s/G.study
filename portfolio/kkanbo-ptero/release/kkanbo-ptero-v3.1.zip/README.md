# 깐보's Ptero V3.1

접속자용 Pterodactyl 서버 상태 현황판입니다.

## V3.1 디자인 변경

- `Server Overview` → `Server Status`
- 현황판의 Discord 브랜드 보라색 제거
- 서버 이름의 과한 굵은 글씨 제거
- 하단 내부 설정 문구 제거
- Footer는 `N Servers · Updated` + Discord 시간만 표시
- 같은 상태 그룹 안에서는 Pterodactyl API의 서버 순서를 그대로 유지
- 온라인 서버만 업타임 표시
- 서버 열림/종료 알림도 최소한의 일반 메시지로 표시

## 표시 예시

🦖 깐보's Pterodactyl

Server Status

🟢 ONLINE · 1
팰월드 · 22시간 26분

🔴 OFFLINE · 5
마크 나이트폴
마크 놀이터
마크 서버이벌 26.1.2
마크 서버 2
zomboid

6 Servers · Updated · 오늘 19:49
