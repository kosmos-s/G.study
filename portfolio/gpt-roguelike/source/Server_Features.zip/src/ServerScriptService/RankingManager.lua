local DataStoreService = game:GetService("DataStoreService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local RankingData = require(Modules:WaitForChild("RankingData"))

local RankingManager = {}
local stores = {}
local rankingEvent = nil

local function getStore(boardId)
	if not stores[boardId] then
		stores[boardId] = DataStoreService:GetOrderedDataStore(RankingData.Get(boardId).DataStore)
	end
	return stores[boardId]
end

function RankingManager.Setup(config)
	rankingEvent = config.RankingEvent
end

function RankingManager.Submit(player, boardId, value)
	value = math.floor(value or 0)
	if value <= 0 then return end
	local success, err = pcall(function()
		getStore(boardId):SetAsync(tostring(player.UserId), value)
	end)
	if not success then warn("[RankingManager] submit failed", boardId, player.Name, err) end
end

function RankingManager.SubmitRun(player, publicData)
	publicData = publicData or {}
	RankingManager.Submit(player, "BestSurvivalTime", publicData.BestSurvivalTime or 0)
	RankingManager.Submit(player, "LifetimeKills", publicData.LifetimeKills or 0)
	RankingManager.Submit(player, "TotalClears", publicData.TotalClears or 0)
	RankingManager.Submit(player, "LifetimeGold", publicData.LifetimeGold or 0)
	RankingManager.Submit(player, "LifetimeSoul", publicData.LifetimeSoul or publicData.Soul or 0)
end

function RankingManager.Fetch(boardId)
	local board = RankingData.Get(boardId)
	local rows = {}
	local success, pages = pcall(function()
		return getStore(boardId):GetSortedAsync(false, 10)
	end)
	if success and pages then
		local current = pages:GetCurrentPage()
		for rank, item in ipairs(current) do
			table.insert(rows, { Rank = rank, UserId = tonumber(item.key) or 0, Value = item.value })
		end
	else
		warn("[RankingManager] fetch failed", boardId)
	end
	return { BoardId = boardId, Title = board.Title, ValueName = board.ValueName, Rows = rows }
end

function RankingManager.Send(player, boardId)
	boardId = boardId or "BestSurvivalTime"
	if rankingEvent then
		rankingEvent:FireClient(player, RankingManager.Fetch(boardId))
	end
end

return RankingManager
