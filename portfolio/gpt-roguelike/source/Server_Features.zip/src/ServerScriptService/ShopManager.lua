local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local PlayerStats = require(Modules:WaitForChild("PlayerStats"))
local ShopData = require(Modules:WaitForChild("ShopData"))
local DataManager = require(script.Parent:WaitForChild("DataManager"))

local ShopManager = {}

function ShopManager.Buy(player, itemId)
	local item = ShopData.Get(itemId)
	if not item then return false, "존재하지 않는 상점 아이템입니다." end
	local gold = PlayerStats.Get(player, "Gold")
	if not gold or gold.Value < item.Cost then return false, "Gold가 부족합니다." end
	gold.Value -= item.Cost
	DataManager.AddNextRunShopItem(player, itemId, 1)
	DataManager.SavePlayer(player)
	return true, item.Title .. " 구매 완료! 다음 판에 적용됩니다."
end

function ShopManager.ApplyNextRunBuffs(player)
	local items = DataManager.GetNextRunShopItems(player)
	for itemId, count in pairs(items) do
		if count and count > 0 then
			local item = ShopData.Get(itemId)
			if item and item.StatBonuses then
				for stat, amount in pairs(item.StatBonuses) do
					PlayerStats.Add(player, stat, amount * count)
				end
			end
		end
	end
	DataManager.ClearNextRunShopItems(player)
	PlayerStats.ApplyToCharacter(player, true)
end

function ShopManager.TryRevive(player)
	local revive = PlayerStats.Get(player, "ReviveTokens")
	if revive and revive.Value > 0 then
		revive.Value -= 1
		return true
	end
	return false
end

return ShopManager
