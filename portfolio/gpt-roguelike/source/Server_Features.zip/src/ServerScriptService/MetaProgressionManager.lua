local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local PlayerStats = require(Modules:WaitForChild("PlayerStats"))
local MetaUpgradeData = require(Modules:WaitForChild("MetaUpgradeData"))
local WeaponData = require(Modules:WaitForChild("WeaponData"))

local DataManager = require(script.Parent:WaitForChild("DataManager"))

local MetaProgressionManager = {}

function MetaProgressionManager.ApplyMetaUpgrades(player)
	local data = DataManager.GetData(player)
	local upgrades = data.MetaUpgrades

	for _, upgradeId in ipairs(MetaUpgradeData.Order) do
		local upgrade = MetaUpgradeData.Get(upgradeId)
		local level = upgrades[upgradeId] or 0
		if upgrade and level > 0 then
			PlayerStats.Add(player, upgradeId, level * upgrade.AmountPerLevel)
		end
	end

	PlayerStats.ApplyToCharacter(player, true)
end

function MetaProgressionManager.ApplySelectedWeapon(player)
	PlayerStats.Set(player, "Weapon", DataManager.GetSelectedWeapon(player))
end

function MetaProgressionManager.BuyUpgrade(player, upgradeId)
	local upgrade = MetaUpgradeData.Get(upgradeId)
	if not upgrade then
		return false, "존재하지 않는 강화입니다."
	end

	local data = DataManager.GetData(player)
	local currentLevel = data.MetaUpgrades[upgradeId] or 0
	if currentLevel >= upgrade.MaxLevel then
		return false, "이미 최대 레벨입니다."
	end

	local cost = MetaUpgradeData.GetCost(upgradeId, currentLevel)
	if not cost or not DataManager.SpendSoul(player, cost) then
		return false, "Soul이 부족합니다."
	end

	DataManager.SetMetaUpgradeLevel(player, upgradeId, currentLevel + 1)
	DataManager.SavePlayer(player)
	return true, upgrade.Title .. " 구매 완료!"
end

function MetaProgressionManager.UnlockWeapon(player, weaponId)
	if not WeaponData.IsValid(weaponId) or not WeaponData.IsBaseWeapon(weaponId) then
		return false, "존재하지 않는 무기입니다."
	end

	local weapon = WeaponData.Get(weaponId)
	if DataManager.IsWeaponUnlocked(player, weaponId) then
		return false, "이미 해금된 무기입니다."
	end

	local cost = weapon.Cost or 0
	if cost > 0 and not DataManager.SpendSoul(player, cost) then
		return false, "Soul이 부족합니다."
	end

	DataManager.SetWeaponUnlocked(player, weaponId, true)
	DataManager.SavePlayer(player)
	return true, weapon.Title .. " 해금 완료!"
end

function MetaProgressionManager.SelectWeapon(player, weaponId)
	if not WeaponData.IsValid(weaponId) or not WeaponData.IsBaseWeapon(weaponId) then
		return false, "존재하지 않는 무기입니다."
	end

	if not DataManager.IsWeaponUnlocked(player, weaponId) then
		return false, "아직 해금되지 않은 무기입니다."
	end

	DataManager.SetSelectedWeapon(player, weaponId)
	PlayerStats.Set(player, "Weapon", weaponId)
	DataManager.SavePlayer(player)
	return true, WeaponData.Get(weaponId).Title .. " 선택 완료!"
end

return MetaProgressionManager
