local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local GachaData = require(Modules:WaitForChild("GachaData"))
local InventoryData = require(Modules:WaitForChild("InventoryData"))

local DataManager = require(script.Parent:WaitForChild("DataManager"))

local InventoryManager = {}

function InventoryManager.GetInventory(player)
	local data = DataManager.GetData(player)
	local weapons = {}
	for weaponId, owned in pairs(data.OwnedJobWeapons or {}) do
		if owned then
			local weapon = GachaData.GetWeapon(weaponId)
			if weapon then
				table.insert(weapons, weapon)
			end
		end
	end
	table.sort(weapons, function(a, b)
		local ar = GachaData.GetGradeRank(a.Grade)
		local br = GachaData.GetGradeRank(b.Grade)
		if ar == br then return a.Title < b.Title end
		return ar > br
	end)
	return {
		Weapons = weapons,
		WeaponShards = data.WeaponShards or 0,
		EquippedJobWeapons = table.clone(data.EquippedJobWeapons or {}),
		SelectedJob = data.SelectedJob
	}
end

function InventoryManager.SellJobWeapon(player, weaponId)
	local weapon = GachaData.GetWeapon(weaponId)
	if not weapon then return false, "존재하지 않는 무기입니다." end
	if not DataManager.IsJobWeaponOwned(player, weaponId) then return false, "보유하지 않은 무기입니다." end
	if not InventoryData.CanSellGrade(weapon.Grade) then return false, "S급 무기는 판매할 수 없습니다." end

	local data = DataManager.GetData(player)
	for jobId, equippedId in pairs(data.EquippedJobWeapons or {}) do
		if equippedId == weaponId then
			return false, "장착 중인 무기는 판매할 수 없습니다."
		end
	end

	local shards = InventoryData.GetSellShards(weapon.Grade)
	DataManager.SetJobWeaponOwned(player, weaponId, false)
	DataManager.AddWeaponShards(player, shards)
	DataManager.SavePlayer(player)
	return true, weapon.Title .. " 판매 완료! 조각 +" .. tostring(shards)
end

return InventoryManager
