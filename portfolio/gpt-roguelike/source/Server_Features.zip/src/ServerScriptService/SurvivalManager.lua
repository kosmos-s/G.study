local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local SurvivalData = require(Modules:WaitForChild("SurvivalData"))

local SurvivalManager = {}

local running = false
local elapsedTime = 0
local lastStatusTime = 0
local lastSpawnTime = 0
local nextBossIndex = 1

function SurvivalManager.Start()
	running = true
	elapsedTime = 0
	lastStatusTime = 0
	lastSpawnTime = 0
	nextBossIndex = 1
end

function SurvivalManager.Stop()
	running = false
end

function SurvivalManager.IsRunning()
	return running
end

function SurvivalManager.GetElapsedTime()
	return elapsedTime
end

function SurvivalManager.GetDuration()
	return SurvivalData.Duration
end

function SurvivalManager.Step(deltaTime, callbacks)
	if not running then
		return
	end

	callbacks = callbacks or {}
	elapsedTime += math.max(0, deltaTime or 0)

	if elapsedTime - lastStatusTime >= (SurvivalData.StatusUpdateInterval or 0.25) then
		lastStatusTime = elapsedTime
		if callbacks.OnStatus then
			callbacks.OnStatus({
				Time = elapsedTime,
				Duration = SurvivalData.Duration,
				Progress = math.clamp(elapsedTime / SurvivalData.Duration, 0, 1)
			})
		end
	end

	local rule = SurvivalData.GetSpawnRule(elapsedTime)
	if rule and elapsedTime - lastSpawnTime >= rule.Interval then
		lastSpawnTime = elapsedTime
		if callbacks.OnSpawnWave then
			callbacks.OnSpawnWave(rule, SurvivalData.GetProgressLevel(elapsedTime))
		end
	end

	while nextBossIndex <= #SurvivalData.BossEvents do
		local bossEvent = SurvivalData.BossEvents[nextBossIndex]
		if elapsedTime < bossEvent.Time then
			break
		end

		nextBossIndex += 1
		if callbacks.OnBoss then
			callbacks.OnBoss(bossEvent, SurvivalData.GetProgressLevel(elapsedTime))
		end
	end
end

return SurvivalManager
