local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local GachaData = require(Modules:WaitForChild("GachaData"))
local TradeData = require(Modules:WaitForChild("TradeData"))

local DataManager = require(script.Parent:WaitForChild("DataManager"))

local TradeManager = {}
local tradeUpdateEvent = nil
local sessions = {}
local pendingInvites = {}

local function send(player, payload)
	if tradeUpdateEvent then tradeUpdateEvent:FireClient(player, payload) end
end

local function keyFor(a, b)
	local ids = { a.UserId, b.UserId }
	table.sort(ids)
	return tostring(ids[1]) .. "_" .. tostring(ids[2])
end

function TradeManager.Setup(config)
	tradeUpdateEvent = config.TradeUpdateEvent
end

function TradeManager.Request(fromPlayer, targetName)
	local target = Players:FindFirstChild(targetName)
	if not target or target == fromPlayer then return false, "대상을 찾을 수 없습니다." end
	pendingInvites[target] = fromPlayer
	send(target, { Type = "Invite", From = fromPlayer.Name })
	return true, target.Name .. "에게 거래 요청을 보냈습니다."
end

function TradeManager.Respond(player, accepted)
	local fromPlayer = pendingInvites[player]
	pendingInvites[player] = nil
	if not fromPlayer or not fromPlayer.Parent then return false, "만료된 거래 요청입니다." end
	if not accepted then send(fromPlayer, { Type = "Message", Message = player.Name .. "님이 거래를 거절했습니다." }) return true, "거절했습니다." end
	local key = keyFor(player, fromPlayer)
	sessions[key] = { A = fromPlayer, B = player, Items = { [fromPlayer.UserId] = {}, [player.UserId] = {} }, Ready = { [fromPlayer.UserId] = false, [player.UserId] = false } }
	send(fromPlayer, { Type = "Open", Partner = player.Name, SessionKey = key })
	send(player, { Type = "Open", Partner = fromPlayer.Name, SessionKey = key })
	return true, "거래 시작"
end

local function getSession(player)
	for key, session in pairs(sessions) do
		if session.A == player or session.B == player then return key, session end
	end
	return nil, nil
end

local function broadcast(session, payload)
	send(session.A, payload)
	send(session.B, payload)
end

local function buildState(session)
	return {
		Type = "State",
		A = session.A.Name,
		B = session.B.Name,
		Items = session.Items,
		Ready = session.Ready
	}
end

function TradeManager.Offer(player, weaponId)
	local key, session = getSession(player)
	if not session then return false, "진행 중인 거래가 없습니다." end
	local weapon = GachaData.GetWeapon(weaponId)
	if not weapon then return false, "존재하지 않는 무기입니다." end
	if not TradeData.CanTradeGrade(weapon.Grade) then return false, "이 등급은 거래할 수 없습니다." end
	if not DataManager.IsJobWeaponOwned(player, weaponId) then return false, "보유하지 않은 무기입니다." end
	local list = session.Items[player.UserId]
	for _, id in ipairs(list) do if id == weaponId then return false, "이미 등록된 무기입니다." end end
	if #list >= TradeData.MaxItemsPerSide then return false, "거래 등록 개수 제한입니다." end
	table.insert(list, weaponId)
	session.Ready[session.A.UserId] = false
	session.Ready[session.B.UserId] = false
	broadcast(session, buildState(session))
	return true, "등록 완료"
end

function TradeManager.Ready(player)
	local key, session = getSession(player)
	if not session then return false, "진행 중인 거래가 없습니다." end
	session.Ready[player.UserId] = true
	broadcast(session, buildState(session))
	if session.Ready[session.A.UserId] and session.Ready[session.B.UserId] then
		for _, id in ipairs(session.Items[session.A.UserId]) do if not DataManager.IsJobWeaponOwned(session.A, id) then TradeManager.Cancel(session.A) return false, "아이템 검증 실패" end end
		for _, id in ipairs(session.Items[session.B.UserId]) do if not DataManager.IsJobWeaponOwned(session.B, id) then TradeManager.Cancel(session.B) return false, "아이템 검증 실패" end end
		for _, id in ipairs(session.Items[session.A.UserId]) do DataManager.SetJobWeaponOwned(session.A, id, false); DataManager.SetJobWeaponOwned(session.B, id, true) end
		for _, id in ipairs(session.Items[session.B.UserId]) do DataManager.SetJobWeaponOwned(session.B, id, false); DataManager.SetJobWeaponOwned(session.A, id, true) end
		DataManager.SavePlayer(session.A); DataManager.SavePlayer(session.B)
		broadcast(session, { Type = "Complete", Message = "거래 완료" })
		sessions[key] = nil
	end
	return true, "준비 완료"
end

function TradeManager.Cancel(player)
	local key, session = getSession(player)
	if not session then return false, "진행 중인 거래가 없습니다." end
	broadcast(session, { Type = "Closed", Message = "거래가 취소되었습니다." })
	sessions[key] = nil
	return true, "취소됨"
end

return TradeManager
