local ReplicatedStorage = game:GetService("ReplicatedStorage")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local PlayerStats = require(Modules:WaitForChild("PlayerStats"))
local JobData = require(Modules:WaitForChild("JobData"))
local GachaData = require(Modules:WaitForChild("GachaData"))
local RobuxProductData = require(Modules:WaitForChild("RobuxProductData"))

local DataManager = require(script.Parent:WaitForChild("DataManager"))

local GachaManager = {}
local resultEvent = nil
local metaDataEvent = nil

local function drawOneWithoutCost(player)
	local jobId = DataManager.GetSelectedJob(player)
	local pity = DataManager.GetGachaPity(player)
	local grade = GachaData.RollGrade(pity)
	local weapon = GachaData.GetRandomWeapon(jobId, grade)
	local duplicate = DataManager.IsJobWeaponOwned(player, weapon.Id)
	local shards = 0

	if duplicate then
		shards = GachaData.GetShardValue(weapon.Grade)
		DataManager.AddWeaponShards(player, shards)
	else
		DataManager.SetJobWeaponOwned(player, weapon.Id, true)
	end

	DataManager.UpdateGachaPity(player, weapon.Grade)

	return {
		Id = weapon.Id,
		Title = weapon.Title,
		Grade = weapon.Grade,
		WeaponType = weapon.WeaponType,
		Duplicate = duplicate,
		Shards = shards
	}
end

function GachaManager.Setup(config)
	resultEvent = config.RobuxGachaResultEvent
	metaDataEvent = config.MetaDataEvent
end

function GachaManager.Draw(player, count)
	count = count == 10 and 10 or 1
	local cost = count == 10 and GachaData.CostTen or GachaData.CostSingle
	if not DataManager.SpendSoul(player, cost) then
		return false, "Soul이 부족합니다.", {}
	end

	local results = {}
	for _ = 1, count do
		table.insert(results, drawOneWithoutCost(player))
	end

	DataManager.SavePlayer(player)
	return true, tostring(count) .. "회 뽑기 완료!", results
end

function GachaManager.DrawRobux(player, count)
	count = count == 10 and 10 or 1
	local results = {}
	for _ = 1, count do
		table.insert(results, drawOneWithoutCost(player))
	end
	DataManager.SavePlayer(player)
	return true, "Robux " .. tostring(count) .. "회 뽑기 지급 완료!", results
end

function GachaManager.ProcessReceipt(receiptInfo)
	local _, product = RobuxProductData.FindByProductId(receiptInfo.ProductId)
	if not product then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end

	local player = Players:GetPlayerByUserId(receiptInfo.PlayerId)
	if not player then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end

	local success, message, results = GachaManager.DrawRobux(player, product.PullCount)
	if success then
		if resultEvent then
			resultEvent:FireClient(player, DataManager.GetPublicData(player), message, results)
		end
		if metaDataEvent then
			metaDataEvent:FireClient(player, DataManager.GetPublicData(player), message)
		end
		return Enum.ProductPurchaseDecision.PurchaseGranted
	end

	warn("[GachaManager] Robux receipt failed:", message)
	return Enum.ProductPurchaseDecision.NotProcessedYet
end

function GachaManager.Equip(player, weaponId)
	local weapon = GachaData.GetWeapon(weaponId)
	if not weapon then return false, "존재하지 않는 직업 무기입니다." end
	if not DataManager.IsJobWeaponOwned(player, weaponId) then return false, "아직 보유하지 않은 무기입니다." end

	local jobId = DataManager.GetSelectedJob(player)
	local pool = GachaData.GetPool(jobId)
	local belongsToJob = false
	for _, item in ipairs(pool) do
		if item.Id == weaponId then belongsToJob = true break end
	end
	if not belongsToJob then return false, "현재 직업에 맞는 무기가 아닙니다." end

	DataManager.SetEquippedJobWeapon(player, jobId, weaponId)
	DataManager.SavePlayer(player)
	return true, weapon.Title .. " 장착 완료!"
end

function GachaManager.ApplyEquippedJobWeapon(player, applyBonuses)
	local jobId = DataManager.GetSelectedJob(player)
	local weaponId = DataManager.GetEquippedJobWeapon(player, jobId)
	local weapon = GachaData.GetWeapon(weaponId)

	if not weapon then
		local job = JobData.Get(jobId)
		local fallbackWeapon = job.PreferredWeapons and job.PreferredWeapons[1] or "Sword"

		PlayerStats.Set(player, "JobWeapon", "")
		PlayerStats.Set(player, "Weapon", fallbackWeapon)
		return nil
	end

	PlayerStats.Set(player, "JobWeapon", weapon.Id)
	PlayerStats.Set(player, "Weapon", weapon.WeaponType or "Sword")

	if applyBonuses ~= false and weapon.StatBonuses then
		for stat, amount in pairs(weapon.StatBonuses) do
			PlayerStats.Add(player, stat, amount)
		end
	end

	return weapon
end

MarketplaceService.ProcessReceipt = GachaManager.ProcessReceipt

return GachaManager
