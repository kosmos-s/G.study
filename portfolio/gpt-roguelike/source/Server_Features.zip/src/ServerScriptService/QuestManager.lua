local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local QuestData = require(Modules:WaitForChild("QuestData"))

local DataManager = require(script.Parent:WaitForChild("DataManager"))

local QuestManager = {}

local questEvent = nil
local runProgress = {}

local function getProgress(player)
	if not runProgress[player] then
		runProgress[player] = {
			Kills = 0,
			Gold = 0,
			Level = 1,
			SurvivalTime = 0,
			Evolution = 0,
			Completed = {}
		}
	end

	return runProgress[player]
end

local function getPublicProgress(player)
	local progress = getProgress(player)
	local public = {}

	for _, questId in ipairs(QuestData.Order) do
		local quest = QuestData.Get(questId)
		local value = progress[quest.Type] or 0

		public[questId] = {
			Value = math.min(value, quest.Target),
			Target = quest.Target,
			CompletedThisRun = progress.Completed[questId] == true
		}
	end

	return public
end

local function send(player, message)
	if questEvent then
		questEvent:FireClient(player, getPublicProgress(player), message)
	end
end

local function completeQuest(player, questId)
	local progress = getProgress(player)
	if progress.Completed[questId] then
		return
	end

	local quest = QuestData.Get(questId)
	if not quest then
		return
	end

	progress.Completed[questId] = true
	DataManager.AddSoul(player, quest.SoulReward or 0)
	DataManager.CompleteQuest(player, questId)
	send(player, quest.Title .. " 완료! Soul +" .. tostring(quest.SoulReward or 0))
end

local function checkQuests(player)
	local progress = getProgress(player)

	for _, questId in ipairs(QuestData.Order) do
		local quest = QuestData.Get(questId)
		if quest then
			local value = progress[quest.Type] or 0

			if value >= quest.Target then
				completeQuest(player, questId)
			end
		end
	end
end

function QuestManager.Setup(events)
	questEvent = events.QuestEvent
end

function QuestManager.ResetRun(player)
	runProgress[player] = nil
	send(player)
end

function QuestManager.AddKills(player, amount)
	local progress = getProgress(player)
	progress.Kills += amount
	checkQuests(player)
	send(player)
end

function QuestManager.AddGold(player, amount)
	local progress = getProgress(player)
	progress.Gold += amount
	checkQuests(player)
	send(player)
end

function QuestManager.SetLevel(player, level)
	local progress = getProgress(player)
	progress.Level = math.max(progress.Level or 1, level)
	checkQuests(player)
	send(player)
end

function QuestManager.SetSurvivalTime(player, time)
	local progress = getProgress(player)
	progress.SurvivalTime = math.max(progress.SurvivalTime or 0, math.floor(time or 0))
	checkQuests(player)
end

function QuestManager.AddEvolution(player)
	local progress = getProgress(player)
	progress.Evolution += 1
	checkQuests(player)
	send(player)
end

function QuestManager.TryAchievement(player, achievementId)
	local achievement = QuestData.GetAchievement(achievementId)
	if not achievement then
		return false
	end

	local unlocked = DataManager.UnlockAchievement(player, achievementId)
	if unlocked then
		DataManager.AddSoul(player, achievement.SoulReward or 0)
		send(player, achievement.Title .. " 업적 달성! Soul +" .. tostring(achievement.SoulReward or 0))
		return true
	end

	return false
end

function QuestManager.Send(player)
	send(player)
end

function QuestManager.ClearPlayer(player)
	runProgress[player] = nil
end

return QuestManager
